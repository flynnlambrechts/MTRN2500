#include "z5360922DirectorRobot.hpp"

int main(int argc, char **argv) {
  DirectorRobot robot;
  robot.run();
  return 0;
}