#pragma once

#include <string>
#include <vector>

std::vector<std::pair<int, std::string>> getOrders();